var config = {};

config.host = 'sale.cmqtqymdfbr9.eu-central-1.rds.amazonaws.com';
config.user = 'sale';
config.password = 'Esi-sose21';
config.port = '3306';

module.exports = config;